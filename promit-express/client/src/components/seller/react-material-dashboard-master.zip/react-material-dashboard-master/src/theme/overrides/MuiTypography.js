export default {
  gutterBottom: {
    marginBottom: 8
  }
};
